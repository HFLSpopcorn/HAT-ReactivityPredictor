The folder "Training" contains the xyz files of optimized structures of intermediates and transition states.

The folder "ConformationalDependence" contains the csv file used in testing the conformational dependence of the PhysOrg-AdaBoost model (Section S5 in Supplementary Information) and the xyz files of optimized structures of intermediates and transition states.

The folder "CHfunctionalization" contains the csv file used as the test set of C–H functionalization substrates (Section S6 in Supplementary Information) and the xyz files of optimized structures of intermediates and transition states.

The folder "ExperimentalKineticsData" contains the csv file used as the test set of HAT reactions that have experimental kinetics data (Section S7 in Supplementary Information) and the xyz files of optimized structures of intermediates. 

The folder "Selectivity" contains the csv file used in selectivity prediction (Section S8 in Supplementary Information) and the xyz files of optimized structures of intermediates and transition states.

For xyz files, those with "PRE" in filename contain the cartesian coordinates of reactants, those with "POST" in filename contain the cartesian coordinates of products, those in folder named "xyz-TS" contain the cartesian coordinates of transition states.